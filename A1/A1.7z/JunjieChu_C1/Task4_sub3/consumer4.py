import pulsar
from conversion import *

# Create a pulsar client by supplying ip address and port
client = pulsar.Client('pulsar://localhost:6650')
# Subscribe to a topic and subscription
consumer = client.subscribe('task4-2', subscription_name='DE-subB')
# Display message received from producer
# msg = consumer.receive()

ITERATION = 11
resultant_string = ""
mylist = []
try:
  for i in range(0,ITERATION):
  	msg = consumer.receive()
  	print("Received message : '%s'" % msg.data())
  	# Acknowledge for receiving the message
  	consumer.acknowledge(msg)
  	
  	string = msg.data()
  	# Split string
	splited_string = string.split(" ")
	print(splited_string)
	mylist.append(splited_string)
  	#resultant_string +=   msg.data()  + ' '
  	
  print('Before sort:')
  print(mylist)
  mylist.sort(key=lambda x:int(x[1]))
  print('After sort:')
  print(mylist)
  
  for j in mylist:
  	resultant_string += j[0] + ' '		 
  print("Resultant String: '%s'" % resultant_string)
  
  
except:
  consumer.negative_acknowledge(msg)
  
# Destroy pulsar client
client.close()

