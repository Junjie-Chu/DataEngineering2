import pulsar
from conversion import *

# Create a pulsar client by supplying ip address and port
client = pulsar.Client('pulsar://localhost:6650')
# Create a producer on the topic that consumer can subscribe to
producer = client.create_producer('task4-1')

ITERATION = 11
# Input string
INPUT_STRING = "I want to be capatilized and want to be tested too"
# Split string
split_string = INPUT_STRING.split(" ")

for i in range(0,ITERATION):
	# Send a message to consumer
	producer.send((split_string[i]+' '+str(i)).encode('utf-8'))
	
# Destroy pulsar client
client.close()


