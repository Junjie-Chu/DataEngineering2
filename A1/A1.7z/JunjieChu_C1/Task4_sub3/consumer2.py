import pulsar
from conversion import *

# Create a pulsar client by supplying ip address and port
client = pulsar.Client('pulsar://localhost:6650')
# Subscribe to a topic and subscription
consumer = client.subscribe('task4-1', subscription_name='DE-subA',consumer_type=pulsar.ConsumerType.Shared)
# Create a producer on the topic that consumer can subscribe to
producer = client.create_producer('task4-2') 
# Display message received from producer
# msg = consumer.receive()

ITERATION = 5
resultant_string = ""
while True:
  try:
  #for i in range(0,ITERATION):
  	msg = consumer.receive()
  	print("Received message : '%s'" % msg.data())
  	print(msg.message_id())
  	# Acknowledge for receiving the message
  	consumer.acknowledge(msg)
  	upper_case_string = conversion(msg.data(), function)
  	# Send a message to consumer
	producer.send((upper_case_string).encode('utf-8'))
	
  	#resultant_string +=   upper_case_string  + ' '
  	
  
  #print("Resultant String: '%s'" % resultant_string)
  
  
  except:
    consumer.negative_acknowledge(msg)


# Destroy pulsar client
client.close()

